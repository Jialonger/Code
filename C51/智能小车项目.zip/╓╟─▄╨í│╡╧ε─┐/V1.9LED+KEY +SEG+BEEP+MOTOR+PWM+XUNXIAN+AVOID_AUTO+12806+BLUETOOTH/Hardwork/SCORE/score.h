#ifndef __SCORE_H_
#define __SCORE_H_

#include "smg.h"


#define uchar unsigned char 
#define uint unsigned int
void key();
void IO_init();
void delay_ms(uint z);
void time_display(uchar w2,uchar d2);
void score_dispaly(uchar w2,uchar d2);

#endif 