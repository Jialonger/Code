#ifndef __LED_H
#define __LED_H

#include "delay.h"

#define LED 		P1
#define LED_COUNT 	7

typedef enum LEDx{LED0,LED1,LED2,LED3,LED4,LED5,LED6,LED7}LEDx;
typedef enum LED_STATE{LED_OFF,LED_ON}LED_STATE;


void LED_Ctrl(LED_STATE led_state , LEDx ledx);
void LED_Mode1(int count,int delayms);
void LED_MODE2(int count,int delayms);

#endif 