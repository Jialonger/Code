#include "reg52.h"
#include "delay.h"
#include "intrins.h"
typedef enum bool{false , true}bool;
sbit LED0 = P1^0;

unsigned char ch = 0xfe; // 1111 1110  0xfe   -   0111 1111  0x7f

unsigned  char isLeft = 1;
unsigned char i = 0;


#define LED_COUNT 7

unsigned char ledstate[] = {0xFE,0XFD,0XFB,0XF7,0XEF,0XDF,0XBF,0X7F};


int main(void)
{

	while(1)
	{
		for(i = 0; i < 4 ; i++)
		{
			P1 = ledstate[ 4 + i ] & ledstate[3-i];
			// 4 3  5 2  6 1  7 0  
			Delay_Xms(200);
		}
		
		for(i = 1; i < 4 ; i++)
		{
			// 1 6  2 5  3 4   
			P1 = ledstate[ i ] & ledstate[LED_COUNT-i];
			Delay_Xms(200);
		}
		
		
		
//		for(i = 0 ; i < 7; i++)
//		{
//			ch = _crol_(ch, 1);	
//			P1 = ch;
//			Delay_Xs(1);
//		}
//		
//		for(i = 0 ; i < 7; i++)
//		{
//			ch = _cror_(ch, 1);	
//			P1 = ch;
//			Delay_Xs(1);
//		}

		
		
		

//		for(i = 0 ; i < 7; i++)
//		{
//			P1 = ledstate[i];
//			Delay_Xs(1);
//		}
//		
//		for(i = 0 ; i < 7; i++)
//		{
//			P1 = ledstate[LED_COUNT - i - 1];
//			Delay_Xs(1);
//		}		
//		
//		P1 = ch;
//		Delay_Xs(1);
		
		
//		// 1111 1110���ƿ�ʼ		�ƶ��� 0111 1111
//		if(isLeft = 1)
//		{
//			ch = _crol_(ch, 1);	
//			// ������Ƶ� 0111 1111 ox7f ��ʼ����
//			if(ch = 0x7f)
//				isLeft = 0;
//		}else{
//			ch = _cror_(ch, 1);
//			// ������Ƶ� 1111 1110 0xfe ��ʼ����
//			if(ch = 0xfe)
//				isLeft = 1;
//		}
		
	
		
	}
	return 0;
}