#ifndef __BEEP_H_
#define __BEEP_H_


#define BEEP P0^7;

#endif // __BEEP_H_