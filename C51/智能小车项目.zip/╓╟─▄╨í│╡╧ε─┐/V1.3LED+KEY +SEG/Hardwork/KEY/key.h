#ifndef __KEY_H_
#define __KEY_H_
#include "reg52.h"
#include "delay.h"
#define KEY P3
typedef enum bool{false = 0 ,true = !false}bool;

typedef enum KEY_STATE{KEY_DOWN,KEY_UP,KEY_ERR}KEY_STATE;
typedef enum KEYx{KEY1=3,KEY2=4,KEY3=6,KEY4=7}KEYx;

bool Fresh_key(KEYx keyx);
#endif //__KEY_H_