#include "bluetooth.h"
/*

	
	typedef enum CAR_STATE{GoHead,GoBack,Stop,StayLeft,StayRight}CAR_STATE;
*/
void Car_Bluetooth_Ctrl(unsigned char ch)
{
	switch(ch)
	{
		//ǰ��
		case 'A':{
			LED_0 = !LED_0;
			Car_Movetion(GoHead);
		}break;
		//��ת
		case 'G':{
			LED_1 = !LED_1;
			Car_Movetion(StayLeft);
		}break;
		//ֹͣ
		case 'Z':{
			LED_2 = !LED_2;
			Car_Movetion(Stop);
		}break;
		//��ת
		case 'C':{
			LED_3 = !LED_3;
			Car_Movetion(StayRight);
		}break;
		//����
		case 'E':{
			LED_4 = !LED_4;
			Car_Movetion(GoBack);
		}break;
	}
}