#ifndef __BLUETOOTH_H_
#define __BLUETOOTH_H_

#include "motor.h"
#include "reg52.h"
#include "led.h"

sbit LED_0 = P1^0;
sbit LED_1 = P1^1;
sbit LED_2 = P1^2;
sbit LED_3 = P1^3;
sbit LED_4 = P1^4;

void Car_Bluetooth_Ctrl(unsigned char ch);

#endif