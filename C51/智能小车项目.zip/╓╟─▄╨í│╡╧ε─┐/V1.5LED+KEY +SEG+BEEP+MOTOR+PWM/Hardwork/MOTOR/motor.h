#ifndef __MOTOR_H_
#define __MOTOR_H_

#include "reg52.h"
/*
	la P0_0
	lb P0_1
	ra P0_2
	rb P0_3
*/



typedef enum MOTORx{MOTOR_L,MOTOR_R}MOTORx;
typedef enum MOTOR_STATE{NEGTIVE,POSITIVE,STOP}MOTOR_STATE;
typedef enum CAR_STATE{GoHead,GoBack,Stop,StayLeft,StayRight}CAR_STATE;

void Car_Movetion(CAR_STATE carstate);

#endif //__MOTOR_H_