//#include "pwm.h"

///* pwm�������	*/
//#define PWMOut_Count 2


//typedef enum PWMx{
//	PWM1,
//	PWM2��
//	PWM_END	
//}PWMx;








//#define PWM0 P0^0 
//void Output_PWM()
//{
//	Cnt++;
//	if(Cnt<Reload)
//	{
//		
//	}else
//	{
//		
//	}
//}
