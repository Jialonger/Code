#ifndef __PWM_H_
#define __PWM_H_

#include "reg52.h"


// 	����Ϊ ת��ֵ(5000)*��С�̶�0.01ms=50ms
typedef struct Config_Pwm{
	
	unsigned int Period;
	unsigned int Reload;
	
}Config_PWM;


#endif //__PWM_H_