#ifndef __INFREAED_H_
#define __INFREAED_H_

#include "reg52.h"
#include "motor.h"

void Car_Tracking(void);

#endif //__INFREAED_H_