// 连接标识符(非字符串连接成非字符串，字符串连接成字符串)
#define __JOIN(x,y) x##y

// 将参数转换成字符(x长度小于5，否则会溢出)
#define __CHAR(x)   #@x

// 将x变成字符串（如果x是宏也不展开）
#define __S(x)   #x

// 将x变成T字符串（如果x是宏也不展开）
#define __ST(x)   _T(#x)

// 将x变成字符串（如果x是宏，展开)
#define _S(x)   __S(x)

// 将x变成字符串（如果x是宏，展开)
#define _ST(x)   __ST(x)

// 将参数连接并转成字符串(遇宏则展开)
#define _TO_STR(x, y)	 	_S(x) "" _S(y)
#define _TO_STRT(x, y) 		_T( _S(x) "" _S(y) )

