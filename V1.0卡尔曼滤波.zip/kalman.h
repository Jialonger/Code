#ifndef __KALMAN_H
#define __KALMAN_H


double KalmanFilter(double ResrcData,double ProcessNiose_Q,double MeasureNoise_R);


#endif

